from picamera import PiCamera
from time import sleep
import cv2
import numpy as np
img = cv2.imread(input("What Picture? "))
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
mask = cv2.inRange(hsv, (100,100,100), (130,155,155))
#mask = cv2.blur(mask, (5,5))
#thresh = cv2.threshold(mask, 200, 255, cv2.THRESH_BINARY)
#cv2.imwrite('Q3_thresh.png', thresh)
M = cv2.moments(mask)
cX = int(M["m10"] / M["m00"])
cY = int (M["m01"] / M["m00"])
print ("Center: (%s , %s)" % (cX, cY))
print (np.arctan(cX/cY))
