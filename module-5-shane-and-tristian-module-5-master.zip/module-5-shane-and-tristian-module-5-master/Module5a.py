from picamera import PiCamera
from time import sleep
import cv2
import numpy as np
camera = PiCamera()
file_name = input('file:')
camera.start_preview()
sleep(5)

camera.capture('/home/pi/Desktop/'+file_name+'.jpg')

camera.stop_preview()

img = cv2.imread(file_name+'.jpg')
width = img.shape[1]
height = img.shape[0]
if width >= height:
    new_height = int((height/width)*200)
    new_width = 200
else:
    new_width = int((width/height)*200)
    new_height = 200
smaller = cv2.resize(img, (new_width, new_height), interpolation = cv2.INTER_AREA)
cv2.imwrite(file_name+'_thmb.jpg', smaller)


